package a.session15;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;

import android.app.Activity;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;

public class MainActivity extends Activity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ImageView mainImageView = (ImageView) findViewById(R.id.imageView);
        ProgressBar progressBar = (ProgressBar) findViewById(R.id.progressBar);
        String imageurl = "http://developer.android.com/assets/images/home/honeycomb-android.png";

        ImageDownloadMessageHandler imageDownloadMessageHandler1= new ImageDownloadMessageHandler(progressBar, mainImageView);
        ImageDownlaodThread imageDownlaodThread = new ImageDownlaodThread(imageDownloadMessageHandler1,imageurl);
        imageDownlaodThread.start();

    }

    class ImageDownlaodThread extends Thread {
        ImageDownloadMessageHandler imageDownloadMessageHandler;
        String imageUrl;

        public ImageDownlaodThread(ImageDownloadMessageHandler imageDownloadMessageHandler, String imageUrl) {
            this.imageDownloadMessageHandler = imageDownloadMessageHandler;
            this.imageUrl = imageUrl;
        }

        @Override
        public void run() {
            Drawable drawable = LoadImageFromWebOperations(imageUrl);
            Message message = imageDownloadMessageHandler.obtainMessage(1, drawable);
            imageDownloadMessageHandler.sendMessage(message);
            System.out.println("Message sent");
        }

    }

    class ImageDownloadMessageHandler extends Handler {
        ProgressBar progressBar;
        View imageTextView;

        public ImageDownloadMessageHandler(ProgressBar progressBar, View imageTextView) {
            this.progressBar = progressBar;
            this.imageTextView = imageTextView;
        }

        @Override
        public void handleMessage(Message message) {
            progressBar.setVisibility(View.GONE);
            imageTextView.setBackgroundDrawable(((Drawable) message.obj));
            imageTextView.setVisibility(View.VISIBLE);
        }

    }

    Drawable LoadImageFromWebOperations(String url) {
        Drawable d = null;
        InputStream is = null;
        try {
            is = (InputStream) new URL(url).getContent();
            d = Drawable.createFromStream(is, "src name");
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return d;
    }

}
